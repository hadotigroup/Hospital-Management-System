<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title><?php echo $companyInfo->company_name;?> | Log in</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="<?php echo base_url()?>public/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- <link href="<?php echo base_url();?>public/css/font-awesome.min.css" rel="stylesheet" type="text/css" /> -->
        <!-- <link href="<?php echo base_url();?>public/css/ionicons.min.css" rel="stylesheet" type="text/css" /> -->
        <!-- <link href="<?php echo base_url();?>public/css/AdminLTE.css" rel="stylesheet" type="text/css" /> -->

</head>

<body>

    
<style type="text/css">
	.header-icon {
		font-family: "trebuchet";
		font-size: 14px;
		color: #E9893D;
		font-weight: bold;
		margin-top: 2px;
	}

	.content-icon {
		font-family: "trebuchet";
		font-weight: bold;
		color: #0171D5;
	}

	.powered{
		margin-top: 50px;
		font-family: "trebuchet";
		font-weight: bold;
		color: #0171D5;
		font-size: 10px;
	}

	.login-icon{
		font-size: 12px;
		font-family: "trebuchet";
	}
</style>




<div class="row">

<br><br><br><br><br><br><br><br>
<center>
	<img src="<?php echo base_url()?>public/img/expiration-img.jpg">
	<br><br><br><br>
Powered by: <a href="http://grafikspointdesign.com/" target="_blank">GrafiksPoint Design</a>
</center>

</div>
	



<script src="<?php echo base_url()?>public/login/js/bootstrap.js"></script>

<script src="<?php echo base_url()?>public/login/js/signin.js"></script>

</body>

</html>
